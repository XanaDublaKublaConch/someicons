"""Named colour palettes for SECAR icon generation."""

from pydantic import BaseModel


class Palette(BaseModel):
    bg_top:   tuple[int, int, int]
    bg_bot:   tuple[int, int, int]
    node:     tuple[int, int, int]
    edge:     tuple[int, int, int]
    accent:   tuple[int, int, int]
    text_top: tuple[int, int, int]
    text_bot: tuple[int, int, int]


PALETTES: dict[str, Palette] = {
    "navy": Palette(
        bg_top=(10, 25, 60),   bg_bot=(5, 45, 90),
        node=(30, 120, 255),   edge=(20, 80, 180),  accent=(0, 180, 255),
        text_top=(200, 230, 255),                   text_bot=(80, 200, 255),
    ),
    "green": Palette(
        bg_top=(10, 40, 20),   bg_bot=(5, 60, 30),
        node=(0, 200, 80),     edge=(0, 140, 60),   accent=(80, 255, 140),
        text_top=(200, 255, 210),                   text_bot=(80, 255, 140),
    ),
    "purple": Palette(
        bg_top=(30, 15, 60),   bg_bot=(50, 20, 80),
        node=(160, 80, 255),   edge=(110, 40, 200), accent=(200, 140, 255),
        text_top=(230, 210, 255),                   text_bot=(200, 140, 255),
    ),
    "amber": Palette(
        bg_top=(40, 25, 10),   bg_bot=(60, 35, 5),
        node=(220, 140, 20),   edge=(160, 100, 15), accent=(255, 190, 60),
        text_top=(255, 230, 180),                   text_bot=(255, 190, 60),
    ),
    "blue": Palette(
        bg_top=(0, 50, 100),   bg_bot=(0, 30, 70),
        node=(0, 160, 220),    edge=(0, 100, 170),  accent=(90, 210, 255),
        text_top=(210, 240, 255),                   text_bot=(90, 210, 255),
    ),
    "red": Palette(
        bg_top=(60, 10, 10),   bg_bot=(80, 5, 5),
        node=(220, 50, 50),    edge=(160, 30, 30),  accent=(255, 100, 80),
        text_top=(255, 210, 200),                   text_bot=(255, 100, 80),
    ),
    "teal": Palette(
        bg_top=(5, 45, 50),    bg_bot=(5, 30, 40),
        node=(0, 200, 190),    edge=(0, 140, 130),  accent=(80, 255, 245),
        text_top=(200, 255, 250),                   text_bot=(80, 255, 245),
    ),
    "gold": Palette(
        bg_top=(45, 35, 0),    bg_bot=(60, 45, 0),
        node=(210, 170, 0),    edge=(160, 120, 0),  accent=(255, 220, 40),
        text_top=(255, 245, 180),                   text_bot=(255, 220, 40),
    ),
}
