"""secaricons — SECAR jumpbox icon generator."""

__version__ = "1.0.0"
