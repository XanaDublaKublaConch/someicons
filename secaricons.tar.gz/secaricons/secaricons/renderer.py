"""Icon composition: text overlay, rounded-corner mask, .ico export."""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from .background import draw_gradient, draw_network
from .palettes import Palette

# Canvas size for all rendering; downsampled when saving .ico frames
CANVAS = 512
CORNER_RADIUS = 80
ICO_SIZES = [256, 128, 64, 48, 32, 16]
MAX_TEXT_WIDTH_RATIO = 0.82  # label must fit within this fraction of canvas width

_FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    "/usr/share/fonts/truetype/ubuntu/Ubuntu-B.ttf",
]


def _find_font() -> str | None:
    for path in _FONT_CANDIDATES:
        if Path(path).exists():
            return path
    return None


def _fit_font(font_path: str, text: str, start_size: int, max_width: int) -> ImageFont.FreeTypeFont:
    """Return the largest font ≤ start_size whose rendered width fits max_width."""
    dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    size = start_size
    while size > 16:
        ft = ImageFont.truetype(font_path, size)
        bb = dummy_draw.textbbox((0, 0), text, font=ft)
        if (bb[2] - bb[0]) <= max_width:
            return ft
        size -= 2
    return ImageFont.truetype(font_path, 16)


def _rounded_mask(size: int, radius: int) -> Image.Image:
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle([(0, 0), (size - 1, size - 1)], radius=radius, fill=255)
    return mask


def _draw_text(img: Image.Image, top_line: str, bot_line: str, palette: Palette) -> None:
    font_path = _find_font()
    if font_path is None:
        raise RuntimeError("No TrueType font found on this system.")

    max_w = int(CANVAS * MAX_TEXT_WIDTH_RATIO)
    ft_top = _fit_font(font_path, top_line, 110, max_w)
    ft_bot = _fit_font(font_path, bot_line, 90,  max_w)

    draw = ImageDraw.Draw(img)
    w = h = CANVAS

    tb = draw.textbbox((0, 0), top_line, font=ft_top)
    bb = draw.textbbox((0, 0), bot_line, font=ft_bot)
    tw, th = tb[2] - tb[0], tb[3] - tb[1]
    bw, bh = bb[2] - bb[0], bb[3] - bb[1]

    total_h = th + 14 + bh
    top_y   = (h - total_h) // 2
    bot_y   = top_y + th + 14
    tx      = (w - tw) // 2 - tb[0]
    bx      = (w - bw) // 2 - bb[0]

    # drop shadow
    shadow = (0, 0, 0, 180)
    for dx, dy in [(-2, -2), (2, -2), (-2, 2), (2, 2), (0, 3)]:
        draw.text((tx + dx, top_y + dy), top_line, font=ft_top, fill=shadow)
        draw.text((bx + dx, bot_y + dy), bot_line, font=ft_bot, fill=shadow)

    draw.text((tx, top_y), top_line, font=ft_top, fill=(*palette.text_top, 255))
    draw.text((bx, bot_y), bot_line, font=ft_bot, fill=(*palette.text_bot, 255))

    # accent divider
    line_w = int(w * 0.55)
    lx = (w - line_w) // 2
    draw.line([(lx, h // 2 + 4), (lx + line_w, h // 2 + 4)],
              fill=(*palette.accent, 120), width=2)


def render_icon(
    top_line: str,
    bot_line: str,
    palette: Palette,
) -> Image.Image:
    """Render a single RGBA icon image at CANVAS × CANVAS resolution."""
    img = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0))

    # opaque bg for gradient
    bg = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 255))
    draw_gradient(bg, palette)
    img = Image.alpha_composite(img, bg)

    img = draw_network(img, palette, seed=hash(bot_line) & 0xFFFF)
    _draw_text(img, top_line, bot_line, palette)
    img.putalpha(_rounded_mask(CANVAS, CORNER_RADIUS))
    return img


def save_ico(icon: Image.Image, path: Path) -> None:
    """Save *icon* as a multi-resolution .ico file."""
    frames = [icon.resize((s, s), Image.LANCZOS) for s in ICO_SIZES]
    frames[0].save(
        path,
        format="ICO",
        sizes=[(f.width, f.height) for f in frames],
        append_images=frames[1:],
    )


def save_png(icon: Image.Image, path: Path) -> None:
    icon.save(path, "PNG")
