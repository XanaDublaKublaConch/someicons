"""Background rendering: gradient, hex grid, node/edge network, radial glow."""

import math
import random

from PIL import Image, ImageDraw

from .palettes import Palette


def _lerp_color(c1: tuple[int, int, int], c2: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))  # type: ignore[return-value]


def draw_gradient(img: Image.Image, palette: Palette) -> None:
    """Fill *img* in-place with a top-to-bottom linear gradient."""
    draw = ImageDraw.Draw(img)
    w, h = img.size
    for y in range(h):
        r, g, b = _lerp_color(palette.bg_top, palette.bg_bot, y / (h - 1))
        draw.line([(0, y), (w, y)], fill=(r, g, b, 255))


def draw_network(img: Image.Image, palette: Palette, *, seed: int = 0) -> Image.Image:
    """Composite a sparse node/edge network + hex grid + radial glow onto *img*."""
    rng = random.Random(seed)
    w, h = img.size

    overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay, "RGBA")

    # — hex grid (background layer) —
    step = 55
    for row in range(-1, h // step + 2):
        for col in range(-1, w // step + 2):
            cx = col * step + (step // 2 if row % 2 else 0)
            cy = row * int(step * 0.866)
            pts = [
                (cx + step * 0.45 * math.cos(math.radians(a)),
                 cy + step * 0.45 * math.sin(math.radians(a)))
                for a in range(0, 360, 60)
            ]
            draw.polygon(pts, outline=(*palette.edge, 18), fill=None)

    # — node/edge graph —
    nodes = [(rng.randint(30, w - 30), rng.randint(30, h - 30)) for _ in range(28)]

    for i, (x1, y1) in enumerate(nodes):
        for j, (x2, y2) in enumerate(nodes):
            if j <= i:
                continue
            dist = math.hypot(x2 - x1, y2 - y1)
            if dist < 180:
                alpha = int(55 * (1 - dist / 180))
                draw.line([(x1, y1), (x2, y2)], fill=(*palette.edge, alpha), width=1)

    for idx, (x, y) in enumerate(nodes):
        r = rng.randint(3, 7)
        color = (*palette.accent, 130) if idx % 5 == 0 else (*palette.node, 90)
        draw.ellipse([(x - r, y - r), (x + r, y + r)], fill=color)

    img = Image.alpha_composite(img, overlay)

    # — radial glow (centre bloom) —
    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gr = int(w * 0.45)
    for ring in range(gr, 0, -4):
        alpha = int(28 * (1 - ring / gr))
        gd.ellipse(
            [(w // 2 - ring, h // 2 - ring), (w // 2 + ring, h // 2 + ring)],
            fill=(*palette.node, alpha),
        )

    return Image.alpha_composite(img, glow)
