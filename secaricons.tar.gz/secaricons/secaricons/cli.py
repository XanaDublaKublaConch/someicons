"""secaricons — CLI for generating SECAR jumpbox .ico files."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from .palettes import PALETTES
from .renderer import render_icon, save_ico, save_png

app = typer.Typer(
    name="secaricons",
    help="Generate branded SECAR .ico files with a network-style background.",
    add_completion=False,
)
console = Console()


# ── helpers ──────────────────────────────────────────────────────────────────

def _palette_choices() -> str:
    return ", ".join(PALETTES.keys())


def _resolve_output(output: Path, label: str, fmt: str) -> Path:
    """Return a concrete file path, appending filename if output is a directory."""
    if output.is_dir() or not output.suffix:
        output.mkdir(parents=True, exist_ok=True)
        safe = label.replace(" ", "_")
        return output / f"SECAR_{safe}.{fmt}"
    output.parent.mkdir(parents=True, exist_ok=True)
    return output


# ── commands ─────────────────────────────────────────────────────────────────

@app.command()
def make(
    label: Annotated[str, typer.Argument(help="App/category label, e.g. 'Browser'")],
    palette: Annotated[str, typer.Option("--palette", "-p",
        help=f"Colour palette name. Choices: {_palette_choices()}")] = "navy",
    top: Annotated[str, typer.Option("--top", "-t",
        help="Top line of text (default: SECAR)")] = "SECAR",
    output: Annotated[Path, typer.Option("--output", "-o",
        help="Output path — directory or explicit .ico/.png filename.")] = Path("."),
    preview: Annotated[bool, typer.Option("--preview",
        help="Also save a .png preview alongside the .ico")] = False,
) -> None:
    """Generate a single SECAR icon."""
    if palette not in PALETTES:
        console.print(f"[red]Unknown palette '[bold]{palette}[/bold]'. "
                      f"Run [bold]secaricons list-palettes[/bold] to see options.")
        raise typer.Exit(1)

    pal = PALETTES[palette]

    with console.status(f"Rendering [bold]{top} / {label}[/bold] ({palette})…"):
        icon = render_icon(top_line=top, bot_line=label, palette=pal)

    ico_path = _resolve_output(output, label, "ico")
    save_ico(icon, ico_path)
    console.print(f"[green]✓[/green]  [bold]{ico_path}[/bold]")

    if preview:
        png_path = ico_path.with_suffix(".png")
        save_png(icon, png_path)
        console.print(f"[dim]   preview → {png_path}[/dim]")


@app.command(name="batch")
def batch(
    labels: Annotated[str, typer.Argument(
        help="Comma-separated labels, e.g. 'Browser,SSH,CMD'")],
    palette: Annotated[str, typer.Option("--palette", "-p",
        help=f"Palette for all icons. Choices: {_palette_choices()}")] = "navy",
    palettes: Annotated[Optional[str], typer.Option("--palettes",
        help="Comma-separated palettes matching each label (overrides --palette).")] = None,
    top: Annotated[str, typer.Option("--top", "-t",
        help="Top line of text (default: SECAR)")] = "SECAR",
    output: Annotated[Path, typer.Option("--output", "-o",
        help="Output directory.")] = Path("."),
    preview: Annotated[bool, typer.Option("--preview",
        help="Also save .png previews")] = False,
) -> None:
    """Generate multiple icons in one shot."""
    label_list = [l.strip() for l in labels.split(",")]

    if palettes:
        palette_list = [p.strip() for p in palettes.split(",")]
        if len(palette_list) != len(label_list):
            console.print("[red]--palettes count must match label count.")
            raise typer.Exit(1)
    else:
        palette_list = [palette] * len(label_list)

    for pal_name in palette_list:
        if pal_name not in PALETTES:
            console.print(f"[red]Unknown palette '[bold]{pal_name}[/bold]'.")
            raise typer.Exit(1)

    table = Table(box=box.SIMPLE_HEAVY, show_header=True)
    table.add_column("Label",   style="cyan",  no_wrap=True)
    table.add_column("Palette", style="yellow", no_wrap=True)
    table.add_column("Output",  style="green")

    for label, pal_name in zip(label_list, palette_list):
        pal = PALETTES[pal_name]
        with console.status(f"  Rendering [bold]{label}[/bold]…"):
            icon = render_icon(top_line=top, bot_line=label, palette=pal)

        ico_path = _resolve_output(output, label, "ico")
        save_ico(icon, ico_path)

        if preview:
            save_png(icon, ico_path.with_suffix(".png"))

        table.add_row(label, pal_name, str(ico_path))

    console.print(table)


@app.command(name="list-palettes")
def list_palettes() -> None:
    """Show all available colour palettes."""
    table = Table(title="Available Palettes", box=box.ROUNDED)
    table.add_column("Name",    style="bold cyan", no_wrap=True)
    table.add_column("BG Top",  style="dim")
    table.add_column("BG Bot",  style="dim")
    table.add_column("Accent",  style="dim")

    for name, pal in PALETTES.items():
        table.add_row(
            name,
            str(pal.bg_top),
            str(pal.bg_bot),
            str(pal.accent),
        )

    console.print(table)


def main() -> None:
    app()
